import React from 'react';
import { Text, View, StyleSheet, Image,TextInput } from 'react-native';

const CommonText=(props)=> {
  return (
    <View style={styles.inputContainer}>
        <Text style={styles.lables}>{props.lable}</Text>
        <TextInput
          style={styles.inputStyle}
          autoCapitalize="none"
          autoCorrect={false}
          {...props}
        />
      </View>
  );
}

const styles = StyleSheet.create({
  inputStyle: {
    borderWidth: 1,
    borderColor: '#fff',
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderRadius:20,
    fontFamily: 'regular',
    fontSize: 13,
    top:50,
    backgroundColor:"#fff",
    width:"95%",
    left:8
  },
});
export default CommonText;