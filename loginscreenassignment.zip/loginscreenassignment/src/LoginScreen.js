import React,{useState} from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  CheckBox,
  TouchableOpacity,
  ImageBackground,
  Image
} from "react-native";
import CommonText from "../components/CommonText";
const LoginScreen=()=>{
  const [userEmail, setUserEmail] = useState('');
  const [password, setPassword] =   useState('');

// const signIn = () => {                          // <= Added this function
//     const strongRegex = new RegExp("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$");

//     if (!strongRegex.test(userEmail)) {
//         showMessage(MESSAGE.email)
//         return false;
//     } else if (password.length > 8) {
//         showMessage(MESSAGE.password);
//         return false;
//     }
// }


  return(
   <View style={styles.mainContainer}>
   <ImageBackground
   style={{height:"100%",width:"100%"}}
   source={{uri: 'https://upload.wikimedia.org/wikipedia/commons/b/b5/800x600_Wallpaper_Blue_Sky.png?20091002171555'}}
   >
      <Text style={styles.mainHeader}>Home</Text>
      <Text style={{fontSize:20,color:"#000",left:20}}>Welcome To</Text>
      <Text style={{fontSize:20,color:"#000",left:20}}>Back</Text>
      <CommonText 
          placeholder="Enter Mail" 
          placeholderTextColor="#000"
          autoCapitalize="none"
          autoCorrect={false}
          value={userEmail}
          onChangeText={(actualData) => setUserEmail(actualData)}
      />

      <CommonText 
          placeholder="Enter Password" 
          placeholderTextColor="#000"
          autoCapitalize="none"
          autoCorrect={false}
          secureTextEntry={true}
          maxLength={12}
          minLength={8}
          value={password}
          pattern={[
            '^.{8,}$', 
            '(?=.*\\d)', 
            '(?=.*[A-Z])',
          ]}
          onChangeText={(actualData) => setPassword(actualData)}
      />
      <View style={styles.wraper}>
      <Text style={{color:"#000"}}>8 Characters min 12 max</Text>
      <Text style={{color:"#000"}}>1 Lower case characters </Text>
      <Text style={{color:"#000"}}>1 Uper case characters</Text>
      <Text style={{color:"#000"}}>1 Numerical case characters</Text>
      <Text style={{color:"#000"}}>1 Special case characters</Text>
      </View>
      <View style={{top:"25%",left:20}}>
      <Text style={{fontSize:30,color:"#000"}}>Sign In</Text>
      </View>
      <View style={{top:"20%",left:"80%"}}>
      <TouchableOpacity style={{color:"#000"}}
      // onPress={() => signIn()}>
      >
       <Image 
       style={{backgroundColor:"#000000",height:30,width:30,borderRadius:30}}
       source={{uri:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6C17ItQwOtfp1ywLEWeonmFT7XRPy7VoEkg&usqp=CAU", width:20,height:20, }}/>
      </TouchableOpacity>
      </View>
      </ImageBackground>
    </View>
  );
}
const styles = StyleSheet.create({
  mainContainer: {
    height: '100%',
    width:"100%",
  },
  mainHeader: {
    fontSize: 35,
    color: '#000',
    left:20,
    paddingTop: 50,
    paddingBottom: 35,
  },
  wraper: {
    top:50,
    left:10
  },
});

export default LoginScreen;